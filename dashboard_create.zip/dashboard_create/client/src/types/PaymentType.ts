import { User } from "./UserType";

export type Payment = {
    amount: string,
    currency: string,
    date: string,
    memo: string,
    id: string,
    receiver: User,
    sender: User,
    isLocal?: boolean,
}