export type User = {
    id: Number,
    name: string
}