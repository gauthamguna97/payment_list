import { Payment } from "./PaymentType";
export type PaymentListType = Array<Payment>;
