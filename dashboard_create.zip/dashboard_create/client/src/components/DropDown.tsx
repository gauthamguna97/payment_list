import React from 'react';

type Props = {
    setCurrency: Function,
    currencies: Array<string>
}
const DropDown = (props: Props) => {
    
    const { currencies, setCurrency } = props;

    return(
        <div>
            <select onChange={(item) =>setCurrency(item.currentTarget.value)}>
                {currencies.map(item => (
                    <option value={item}>{item}</option>
                ))}
            </select>
        </div>
    )
}

export default DropDown