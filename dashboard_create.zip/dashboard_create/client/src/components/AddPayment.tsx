import EventEmitter from 'events';
import React, { BaseSyntheticEvent, ChangeEvent, MouseEvent, useEffect, useState } from 'react';
import { useAppDispatch } from '../store/hooks';
import { Payment } from '../types/PaymentType';
import { updatePayment } from '../features/payment/paymentSlice';
import '../styles/addpayment.css'
import DropDown from './DropDown';
import UserName from './UserName';
import CurrencyInput from 'react-currency-input-field';

const ReactFormLabel = (props: {htmlFor: string, title: string}) => {
    return(
        <label htmlFor={props.htmlFor}>{props.title}</label>
    )
}
const AddPayment = () => {

    const currencies = ['BTC', 'GBP', 'EUR', 'JPY', 'USD']
    const dispatcher = useAppDispatch();
    const [users, setUsers]: [Array<{id: Number, name: string}>, Function] = useState([]);
    const [transactionState, SetTransactionState] : [Number, Function] = useState(0);
    const [sender, setSender] = useState("");
    const [receiver, setReceiver] = useState("");
    const [currency, setCurrency] = useState("BTC");
    const [amount, setAmount] = useState("");
    const [payment, setPayment] = useState(false);

    const createData = (event: React.FormEvent<HTMLFormElement>) => {
        SetTransactionState(1);
        event.stopPropagation();
        event.preventDefault();
        const postingData: {
            status: string,
            message?: string | undefined,
            data?: {
                amount: string,
                senderObj: {id: Number, name: string},
                receiverObj: {id: Number, name: string},
                currency: string
            }} = checkValid();


        if (postingData.status === 'Ok' && postingData.data) {
            const data = {
                amount: postingData.data.amount,
                currency: postingData.data.currency,
                date: new Date(Date.now()).toISOString(),
                id: String(Date.now()),
                memo: "",
                sender: postingData.data.senderObj,
                receiver: postingData.data.receiverObj,
                isLocal: true,
            }
            postData(data)
        } else {
            alert(postingData.message)
            SetTransactionState(0);
        }
    }

    const checkValid = () => {

        const senderArr = getId('sender', sender);
        const receiverArr = getId('receiver' , receiver);

        if (senderArr.length === 1 && receiverArr.length === 1) {
            if (senderArr[0]?.id === receiverArr[0]?.id) {
                return {
                    status: 'Error',
                    message: 'Sender and Receiver are same'
                }
            } else {
                return {
                    status: 'Ok',
                    data: {
                        senderObj: senderArr[0],
                        receiverObj: receiverArr[0],
                        currency,
                        amount,
                    }
                }
            }
        } else {
            return {
                status: 'Error',
                message: senderArr.length === 0 ? 'Enter valid Sender' : 'Enter valid Receiver'
            }
        }
    }


    const getId = (type: String, name: String):Array<{id: Number, name: string}>  => {
        // sender check
        var user = users.filter(item => item.name === name)
        return user
    }


    const postData = (data: Payment) => {
        fetch('http://localhost:8080/payments', {
            method: 'POST',
            headers: {
            'Content-Type': 'application/json',
            },
            body: JSON.stringify(data),
        })
        .then(res => {
            if (res.status === 503) {
                postData(data)
            } else if (res.status === 201) {
                setPayment(false);
                setSender("");
                setReceiver("");
                SetTransactionState(0);
                dispatcher(updatePayment({payment: data}))
            }
        })
    }

    useEffect(() => {
        fetch('http://localhost:8080/users')
            .then(res => res.json())
                .then(res => {
                    setUsers(res.data || [])
                })
    }, []);



    const setSenderState = (value: string) => {
        setSender(value);
    }

    const setReceiverState = (value: string) => {
        setReceiver(value);
    }

    const setCurrencyState = (value: string) => {
        setCurrency(value);
    }

    const setAmountState = (value: string | undefined) => {
        setAmount(value || "");
    }

    const openPopUp = () => {
        setPayment(true)
    }

    const closePopup = (e: React.MouseEvent<HTMLDivElement, globalThis.MouseEvent>) => {
        e.stopPropagation();
        e.preventDefault();
        setPayment(false)
    }


    return(
        <div>
            {transactionState === 1 &&
                <div className="popup-container2">
                    <div className="loader"></div>
                </div>
            }
            {!payment &&
                <div className='buttonwrap' onClick={(e) => openPopUp()}>
                    <button className='addbutton' style={{fontSize: 16}}>
                        Add Transaction
                        <div className='imagewrap'>
                            <i className="fa fa-plus" />
                        </div>
                    </button>
                </div>
            }
            {payment &&
                <div className="popup-container" onClick={(e) => closePopup(e)}>
                    <form className='react-form' onClick={(e) => e.stopPropagation()} onSubmit={(e) => createData(e)}>
                        <div className="close" onClick={(e) => closePopup(e)}>x</div>
                        <fieldset className='form-group'>
                            <ReactFormLabel htmlFor='Sender' title='Sender:' />
                            <UserName users={users} sender={sender} setSender={setSenderState}  />
                        </fieldset>
                        <fieldset className='form-group'>
                            <ReactFormLabel htmlFor='Receiver' title='Receiver: ' />
                            <UserName users={users} sender={receiver} setSender={setReceiverState} />
                        </fieldset>
                        <fieldset className='form-group'>
                            <ReactFormLabel htmlFor='Amount' title='Amount:'/>
                            <CurrencyInput
                                id="input-example"
                                placeholder="Enter a Number between 1-10000"
                                decimalsLimit={2}
                                maxLength={8}
                                onValueChange={(value) => setAmountState(value)}
                            />
                        </fieldset>
                        <fieldset className='form-group'>
                            <ReactFormLabel htmlFor='Currency' title='Currency:' />
                            <DropDown currencies={currencies} setCurrency={setCurrencyState} />
                        </fieldset>
                        <div className='form-group'>
                            <input id='formButton' className='btn' type='submit' placeholder='Send message' />
                        </div>
                    </form>
                </div>
            }
        </div>
    )
}

export default AddPayment;
