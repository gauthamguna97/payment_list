import { current } from 'immer';
import React from 'react';

type Props = {
    current: string,
    active: string | null,
}
const Arrow = (props: Props) => {
    const { active, current }  = props;

    if (active && active.startsWith(current)) {
        const cls = active.split('-')[1];
        return <div className={cls}></div>
    }
    return null;
}

export default Arrow