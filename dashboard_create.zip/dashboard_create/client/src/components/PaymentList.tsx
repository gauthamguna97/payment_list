import React, { useEffect, useState } from 'react';
import { useSelector } from 'react-redux';
import { useAppDispatch } from '../store/hooks';
import { RootState } from '../store/store';
import { PaymentListType } from '../types/PaymentListType';
import { updatePayment } from '../features/payment/paymentSlice';
import '../styles/payments.css';
import { Payment } from '../types/PaymentType';
import Arrow from './Arrow';

const PaymentList = () => {
  const Tlist = useSelector((state: RootState): PaymentListType => state.payment.data);
  const dispatcher = useAppDispatch();
  const [currentSelect, setCurrentSelect] = useState("");
  const [searchText, setSearchText] = useState("");
  const searchValue = useSelector((state: RootState): string => state.payment.search);

  // API CALL
  const getData = () => {
    fetch('http://localhost:8080/payments')
      .then(res => res.json())
      .then((res) => {
        console.log(res.data)
        dispatcher(updatePayment({payment: res.data}));
      })
  }

  // ON LOAD CALL API
  useEffect(() => {
    getData();
    const a = setInterval(() => {
      getData();
    }, 2000);
    return () => {
      clearInterval(a);
    }
  }, []);

  const reset = (e: React.MouseEvent<HTMLElement>) => {
    const value = e.currentTarget.getAttribute('data-id')
    console.log(value)
    if (!value) {
      return;
    }
    var toSet = ""
    if (!currentSelect || currentSelect.indexOf(value) === -1 || currentSelect.indexOf('asc') === -1) {
      toSet = value + "-asc";
    } else {
      toSet = value + "-des";
    }
    setCurrentSelect(toSet);
    sortTable(value, toSet.split("-")[1])
  };

  const sortTable = (value: string |  null, type: string) => {
    if (value) {
      dispatcher(updatePayment({value, type}));
    }
  }

  const filterValue = (text: string) => {
    dispatcher(updatePayment({search: text}));
    setSearchText(text)
  }

  return(
    <div>
      <header className='header'>
        <div>Payments Data Dashboard</div>
      </header>
      <div className="container">
        <div className="search-box">
          <input type="text" value={searchText} className="search-input" placeholder="Search.." onChange={(e) => filterValue(e.target.value || "")} />
        </div>
      </div>
      <table>
        <thead>
          <tr>
            <th>
              <div data-id="date" onClick={(e) => reset(e)}>Date</div>
              <Arrow current={'date'} active={currentSelect}/>
            </th>
            <th>
              <div data-id="sender" onClick={(e) => reset(e)} >Sender</div>
              <Arrow current={'sender'} active={currentSelect}/>
            </th>
            <th>
              <div data-id="receiver" onClick={(e) => reset(e)}>Receiver</div>
              <Arrow current={'receiver'} active={currentSelect}/>
            </th>
            <th>
              <div data-id="amount" onClick={(e) => reset(e)}>Amount</div>
              <Arrow current={'amount'} active={currentSelect}/>
            </th>
            <th>
              <div>Currency</div>
            </th>
          </tr>
        </thead>
        {Tlist.map((item) => {
          const date = new Date(item.date);
          return (
            <tr key={item.id}>
              <td>{date.toLocaleString()}</td>
              <td>{item.isLocal ? <strong>{item.sender.name}</strong> : item.sender.name}</td>
              <td>{item.isLocal ? <strong>{item.receiver.name}</strong> : item.receiver.name}</td>
              <td>{item.amount}</td>
              <td>{item.currency}</td>
            </tr>
          )
      })}
      </table>
    </div>
  )
}

export default PaymentList;
