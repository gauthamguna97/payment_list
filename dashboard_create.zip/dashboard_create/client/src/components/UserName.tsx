import React, { ChangeEvent, MouseEvent, useState } from 'react';

type Props = {
    users: Array<{id: Number, name: string}>
    setSender: Function
    sender: string
}

const UserName = (props: Props) => {

    const { users, setSender, sender } = props;

    const [autoList, setAutoList] : [Array<{id: Number, name: string}>, Function] = useState([]);

    const onChange = (event: ChangeEvent<HTMLInputElement>) => {
        const value = event.target.value;
        setSender(value);
        if (!value){
            setAutoList([]);
            return;
        }
        var filterUsers = users.filter((item) => item.name.toLowerCase().startsWith(value.toLowerCase()))
        setAutoList(filterUsers);
    };

    const handleClick = (e: MouseEvent<HTMLDivElement>) => {
        e.stopPropagation();
        var value = e.currentTarget.getAttribute('data-value');
        setSender(value);
        setAutoList([]);
    }

    return(
        <div>
            <input id='formName' className='form-input' name='Sender' type='text' placeholder='Senders Name' required onChange={(e) => onChange(e)} value={sender} />
            {autoList.length > 0 &&
                <div className='autocomplete-items' id='autocomplete-list'>
                    {autoList.map(item =>(
                        <div data-value={item.name} onClick={(e) => handleClick(e)}>
                            <strong>{item.name.substring(0, sender.length)}</strong>
                            {item.name.substring(sender.length)}
                        </div>
                    ))}
                </div>
            }
        </div>
    );
}

export default UserName