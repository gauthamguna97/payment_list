import React from 'react';
import './styles/App.css';
import AddPayment from './components/AddPayment';
import PaymentList from './components/PaymentList';

function App() {
  return (
    <div className="App">
      <PaymentList />
      <AddPayment />
    </div>
  );
}

export default App;
