import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { stat } from 'fs';
import { RootState } from '../../store/store';
import { PaymentListType } from '../../types/PaymentListType';
import { Payment } from '../../types/PaymentType';

export interface ListState {
  data: PaymentListType,
  key: string,
  type: string,
  pdata: PaymentListType,
  search: string,
}

const initialState: ListState = {
  data: [],
  type: 'asc',
  key: 'date',
  pdata: [],
  search: "",
};

const dateComparator = (type: string) => {
  var sign = type === 'asc' ? 1 : -1;
  return (a: Payment, b: Payment) => sign * (new Date(b.date).getTime() - new Date(a.date).getTime())
}

const moneyComparator = (type: string) => {
  var sign = type === 'asc' ? 1 : -1;
  return (a: Payment, b: Payment) => sign * (parseFloat(a.amount) - parseFloat(b.amount));
}

const sComparator = (type: string) => {
  var sign = type === 'asc' ? 1 : -1;
  return (a: Payment, b: Payment) => sign * (a.sender.name.localeCompare(b.sender.name));
}

const rComparator = (type: string) => {
  var sign = type === 'asc' ? 1 : -1;
  return (a: Payment, b: Payment) => sign * (a.receiver.name.localeCompare(b.receiver.name));
}

export const paymentSlice = createSlice({
  name: 'payment',
  initialState,
  reducers: {
    // addPayment: (state, action: PayloadAction<Payment>) => {
    //   state.data.push(action.payload)
    // },
    updatePayment: (state, action: PayloadAction<{payment?: Payment, type?: string, value?: string, search?: string}>) => {
      let value = state.pdata
      state.key = action.payload.value || state.key
      state.type = action.payload.type || state.type
      if (action.payload.payment) {
        value = [action.payload.payment, ...state.pdata]
      }
      // pop element if length is greater than 25
      if (value.length > 25) {
        value.pop()
      }
      state.pdata = value
      state.search = action.payload.search !== undefined ? action.payload.search : state.search

      if (state.search.length > 0) {
        value = [...value].filter(item => {
          return (item.sender.name.indexOf(state.search) > -1 || item.receiver.name.indexOf(state.search) > -1 || item.currency.indexOf(state.search) > -1)
        })
      }
      switch(state.key) {
        case 'date':
          value = [...value].sort(dateComparator(state.type))
          break;
        case 'amount':
          value =[...value].sort(moneyComparator(state.type))
          break;
        case 'sender':
          value =[...value].sort(sComparator(state.type))
          break;
        case 'receiver':
          value =[...value].sort(rComparator(state.type))
          break;
      }
      state.data = value
    },
  },
});

export const { updatePayment } = paymentSlice.actions;

export default paymentSlice.reducer;
